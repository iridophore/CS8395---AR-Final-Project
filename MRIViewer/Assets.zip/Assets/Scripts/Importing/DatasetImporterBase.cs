﻿namespace UnityVolumeRendering
{
    public abstract class DatasetImporterBase
    {
        public abstract VolumeDataset Import();
    }
}
